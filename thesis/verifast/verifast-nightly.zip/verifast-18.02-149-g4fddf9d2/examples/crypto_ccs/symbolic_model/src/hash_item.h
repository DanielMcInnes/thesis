#ifndef HASH_ITEM_H
#define HASH_ITEM_H

#include "general.h"
#include "item_constraints.h"

#endif