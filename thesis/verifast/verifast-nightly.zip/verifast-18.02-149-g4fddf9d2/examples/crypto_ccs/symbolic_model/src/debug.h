#ifndef DEBUG_H
#define DEBUG_H

#include "general.h"

#endif
