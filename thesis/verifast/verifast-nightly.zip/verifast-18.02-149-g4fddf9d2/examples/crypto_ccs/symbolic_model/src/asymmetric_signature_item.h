#ifndef ASYMMETRIC_SIGNATURE_ITEM_H
#define ASYMMETRIC_SIGNATURE_ITEM_H

#include "general.h"

#endif
