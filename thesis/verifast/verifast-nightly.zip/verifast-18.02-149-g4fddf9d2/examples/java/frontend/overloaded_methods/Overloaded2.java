public class Overloaded2 extends Overloaded1
{
 
}
