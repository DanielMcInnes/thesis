package be.fedict.neweidapplet;

import javacard.framework.Shareable;


public interface INewEidPoints extends Shareable {
	
	byte sharePoints (byte points);
	    //@ requires true;
	    //@ ensures true;

}
